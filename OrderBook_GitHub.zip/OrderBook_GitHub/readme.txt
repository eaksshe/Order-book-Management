Fileds of messages are taken space seperaded instead of coma seperated.
This project is completed on Win10 with Visual Studio 2017.

steps to run the project:
	1> Keep the text file at any drive on windows
	2> Point the file path in main.cpp
		example - feed_file_path = "E:\\Study\\preparation\\credit_suisse\\data\\data1.txt";
	3> build the project and run.

points covered from requirement-
1> Add To order Book
2> Remove From Order Book
3> Modify the Order Book
4> Trade the order Book
5> following Error handled and it will be printed be before return from main
       a) Corrupted messages
       b) Duplicated order ids (duplicate adds)
       c) Order Mis-Match (for removing order)
       d) Order Mis-Match (for modifying order)
       e) Negative product ids,price,quantity...
6> Errors are shown before main exits.
 
 Test Cases:
 1> data1.txt - Add,Remove the order book
                Remove and Modify Order book when trade message is send
           
 2>Id_mismatch_duplicate.txt - To check Id mismatch during Add And Remove from Order Book.
 3> Id_check.txt - To check Malformed input messages,negative values of Ids,price and quantity
 
 Note: following is mot implemented-
 a) Trades with no corresponding order
 b) Best sell order price at or below best buy order price but no trades occur
 c) Every 10th message and on exit, write out a human-readable representation of the book down to the 5th level for each product id.

