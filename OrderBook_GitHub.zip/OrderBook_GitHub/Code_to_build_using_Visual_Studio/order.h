#pragma once
#include<array>

namespace marketData
{
	enum Side{ B, S };
	enum action { N, R, M, X};

	// Market Order
	struct Order {

		typedef unsigned long int Id;
		typedef unsigned long int Quantity;

		//following six parameters we need to read from text file 
		char type;
		Id productid;
		Id orderid;
		char side;
		Quantity quantity;
		double price;

		bool operator<(const Order& t) const
		{
			return (this->orderid < t.orderid);
		}
		bool operator==(const Order& t) const
		{
			return (this->productid == t.productid);
		}
	};

	struct Trade {
		char action;
		Order::Id productId;
		Order::Quantity quantity;
		double price;
	};


}
