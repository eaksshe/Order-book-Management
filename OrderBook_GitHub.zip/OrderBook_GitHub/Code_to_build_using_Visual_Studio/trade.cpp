#include <iostream>
#include <sstream>
#include <vector>
#include <iomanip>
#include <map>
#include <array>
#include "trade.h"
#include "exception.h"
#include "order.h"
#include"txtReader.cpp"
#include<utility>
#include <algorithm>

void marketData::Trader::processOrder(const std::string &input, std::vector<std::string>&err_msgs)
{

	// Parsing
	try {
		order = marketData::TextReader::parse(input,err_msgs);

	}
	catch (const ParseException&) {
		err_msgs.push_back("Malformed input message: " + input);
		return;
	}

	// Updating the marketData
	try {
		updateBooks(order, err_msgs);
	}
	catch (const updateBooksException&) {
		std::cerr << "Error on adding order to the marketData";
	}

	//executeOrder(order);

	//Printing the output
	// printOutput(myOrderBook);

}

void marketData::Trader::updateBooks(Order &order, std::vector<std::string>&err_msgs) {
	if (order.type == 'N')
		addToOrderBooks(order, err_msgs);
	else if (order.type == 'R')
		removeFromOrderBooks(order, err_msgs);
	else if (order.type == 'M')
		modifyOrderBooks(order, err_msgs);
	else if (order.type == 'X')
	{
		executeTrade(order, err_msgs);
	}
	else
		throw updateBooksException();

}

void marketData::Trader::addToOrderBooks(Order &order, std::vector<std::string>&err_msgs)
{
	auto locator_it = myOrderBook.find(order.orderid);
	if (locator_it != myOrderBook.end())
	{
		err_msgs.push_back("Duplicate Order cant be Added" + std::to_string(order.orderid));

	}
	else
	{
		myOrderBook.insert(std::pair<marketData::Order::Id, Order>(order.orderid, order));
		std::cout << order.type << " " << order.productid << " " << order.orderid << " " << order.side << " " << order.quantity << " " << order.price << std::endl;
	}

	if (order.side == 'B')
	{
		//sell.insert(<double, marketData::Order>order.price, order);

		if (product_id_to_buy.find(order.productid) != product_id_to_buy.end())
		{
			auto itrprodictID = product_id_to_buy.find(order.productid);
			auto itrPrice = itrprodictID->second.find(order.price);
			if (itrPrice != itrprodictID->second.end())
			{
				itrPrice->second.push_back(order);
			}
			else
			{
				vecOforder vecorder;
				vecorder.push_back(order);
				itrprodictID->second[order.price] = vecorder;
			}
		}
		else
		{
			vecOforder vecorder;
			vecorder.push_back(order);
			buyselldata maptemp;
			maptemp[order.price] = vecorder;
			product_id_to_buy[order.productid] = maptemp;
		}
	}
	else
	{
		if (product_id_to_sell.find(order.productid) != product_id_to_sell.end())
		{
			auto itrprodictID = product_id_to_sell.find(order.productid);
			auto itrPrice = itrprodictID->second.find(order.price);
			if (itrPrice != itrprodictID->second.end())
			{
				itrPrice->second.push_back(order);
			}
			else
			{
				vecOforder vecorder;
				vecorder.push_back(order);
				itrprodictID->second[order.price] = vecorder;
			}
		}
		else
		{
			vecOforder vecorder;
			vecorder.push_back(order);
			buyselldata maptemp;
			maptemp[order.price] = vecorder;
			product_id_to_sell[order.productid] = maptemp;
		}
	}

}

void marketData::Trader::removeFromOrderBooks(Order &order, std::vector<std::string>&err_msgs)
{
	auto locator_it = myOrderBook.find(order.orderid);
	
	if (locator_it == myOrderBook.end())
	{

		err_msgs.push_back("Order Id Mismatch :" + std::to_string(order.orderid));

	}
	else
	{
		std::cout << 'R' << " " << (*locator_it).second.orderid << " " << (*locator_it).second.side << " " << (*locator_it).second.quantity << " " << (*locator_it).second.price << std::endl;

		if (order.side == 'B')
		{
			auto itrproductmap = product_id_to_buy.find(order.productid);
			if (itrproductmap != product_id_to_buy.end())
			{
				order.productid = locator_it->second.productid;
				auto itrPricemap = itrproductmap->second.find(order.price);
				if (itrPricemap != itrproductmap->second.end())
				{
					for (auto& ele : itrPricemap->second)
					{
						if (ele.orderid == order.orderid)
						{
							 auto it =std::find(itrPricemap->second.begin(), itrPricemap->second.end(), ele);
							 itrPricemap->second.erase(it);
							break;
						}
					}
				}
			}
		}
		else
		{
			auto itrproductmap = product_id_to_sell.find(order.productid);
			if (itrproductmap != product_id_to_sell.end())
			{
				auto itrPricemap = itrproductmap->second.find(order.price);
				if (itrPricemap != itrproductmap->second.end())
				{
					for (auto& ele : itrPricemap->second)
					{
						if (ele.orderid == order.orderid)
						{
							auto it = std::find(itrPricemap->second.begin(), itrPricemap->second.end(), ele);
							auto status = itrPricemap->second.erase(it);
							status = itrPricemap->second.begin();
							break;
						}
					}
				}
			}
		}

		myOrderBook.erase(locator_it);
	}
}


void marketData::Trader::modifyOrderBooks(Order &order, std::vector<std::string>&err_msgs, bool bIsFromExecute)
{
	auto locator_it = myOrderBook.find(order.orderid);
	if (bIsFromExecute)
	{
		order.productid = locator_it->second.productid;
		locator_it->second.quantity = locator_it->second.quantity - order.quantity;

	}
	else
	{
		locator_it->second = order;

	}
	if (locator_it == myOrderBook.end())
	{
		err_msgs.push_back("Order Id Mismatch cant Modify" + std::to_string(order.orderid));

	}
	else
	{
		if (order.side == 'B')
		{
			auto itrproductmap = product_id_to_buy.find(order.productid);
			if (itrproductmap != product_id_to_buy.end())
			{
				auto itrPricemap = itrproductmap->second.find(order.price);
				if (itrPricemap != itrproductmap->second.end())
				{
					for (auto& ele : itrPricemap->second)
					{
						if (ele.orderid == order.orderid)
						{
							auto it = std::find(itrPricemap->second.begin(), itrPricemap->second.end(), ele);
							it->quantity = it->quantity - order.quantity;
							break;
						}
					}
				}
			}
		}
		else
		{
			auto itrproductmap = product_id_to_sell.find(order.productid);
			if (itrproductmap != product_id_to_sell.end())
			{
				auto itrPricemap = itrproductmap->second.find(order.price);
				if (itrPricemap != itrproductmap->second.end())
				{
					for (auto& ele : itrPricemap->second)
					{
						if (ele.orderid == order.orderid)
						{
							auto it = std::find(itrPricemap->second.begin(), itrPricemap->second.end(), ele);
							it->quantity = it->quantity - order.quantity;
							break;
						}
					}
				}
			}
		}
		std::cout << 'M' << " " << (*locator_it).second.orderid << " " << (*locator_it).second.side << " " << (*locator_it).second.quantity << " " << (*locator_it).second.price << std::endl;
	}

}
void marketData::Trader::executeTrade(Order &order, std::vector<std::string>&err_msgs)
{
	trade.action = order.type;
	trade.productId = order.productid;
	//prize
	trade.price = order.price;

	//quantity
	trade.quantity = order.quantity;

	Order buyOrderIdToremove;
	Order sellOrderIdToremove;

	std::cout << 'X' << " " << trade.productId << " " << trade.quantity << " " << trade.price << std::endl;

	//check if order is present in buy order
	bool bBuyOrderPresent = false;
	bool bremoveBuyOrder = false;
	bool bSellOrderPresent = false;
	bool bmodifyBuyOrder = false;
	bool bremoveSellOrder = false;
	bool bmodifySellOrder = false;
	auto itrproductbuy = product_id_to_buy.find(trade.productId);
	if (itrproductbuy != product_id_to_buy.end())
	{
		for (auto itrPricemap : itrproductbuy->second)
		{
			for (auto ele : itrPricemap.second)
			{
				if (ele.quantity >= trade.quantity && ele.price >= trade.price)
				{
					bBuyOrderPresent = true;
					buyOrderIdToremove = ele;
					if (ele.quantity == trade.quantity)
					{						
						bremoveBuyOrder = true;
						break;
					}
					else
					{
						bmodifyBuyOrder = true;
						break;
					}
				}			
			}
		
			if (bBuyOrderPresent)
				break;
		}
	}

	if (bBuyOrderPresent)
	{

		auto itrproductbuy = product_id_to_sell.find(trade.productId);
		if (itrproductbuy != product_id_to_sell.end())
		{
			for (auto itrPricemap : itrproductbuy->second)
			{
				for (auto ele : itrPricemap.second)
				{
					if (ele.quantity >= trade.quantity && ele.price >= trade.price)
					{
						sellOrderIdToremove = ele;
						bSellOrderPresent = true;
						if (ele.quantity == trade.quantity)
						{
							bremoveSellOrder = true;
							break;
						}
						else
						{
							bmodifySellOrder = true;
							
							break;

						}
					}

				}
				if (bSellOrderPresent)
					break;
			}
		}
	}

	if (bremoveBuyOrder)
	{
		removeFromOrderBooks(buyOrderIdToremove, err_msgs);
	}
	else if (bmodifyBuyOrder)
	{
		buyOrderIdToremove.quantity = trade.quantity;
		modifyOrderBooks(buyOrderIdToremove, err_msgs,true);
	}


	if (bremoveSellOrder)
	{
		removeFromOrderBooks(sellOrderIdToremove, err_msgs);
	}
	else if (bmodifySellOrder)
	{
		sellOrderIdToremove.quantity = trade.quantity;
		modifyOrderBooks(sellOrderIdToremove, err_msgs,true);
	}
}
