#include <iostream>
#include <sstream>
#include <fstream>
#include <functional>
#include "trade.h"
#include "order.h"

int main() 
{
	marketData::Order::Quantity target_size;
	std::string feed_file_path;
	std::ifstream file_stream;

	feed_file_path = "E:\\Study\\preparation\\credit_suisse\\data\\data1.txt";
	file_stream.open(feed_file_path);
	if (!file_stream.is_open()) {
		std::cerr << "Market Data feed file cannot be loaded.";
		abort();
	}
	marketData::Trader Trader;
	std::string line;

	std::vector<std::string> vec_err_msg;
	while (getline(file_stream, line)) 
	{
		Trader.processOrder(line,vec_err_msg);
	}

	for (int i=0;i<vec_err_msg.size();i++)
		std::cout << vec_err_msg[i] << std::endl;
	return 0;
}
