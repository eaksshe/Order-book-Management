#include <sstream>
#include <iostream>
#include"txtReader.h"
#include<vector>



namespace marketData

{
	const std::string kBuy = "B";
	const std::string kSell = "S";
	const std::string kNewOrder = "N";
	const std::string kRemoveOrder = "R";
	const std::string kModifyOrder = "M";
	const std::string kTradeOrder = "X";
	class TextReader
	{
		// Basic Market Order Parse
	public:
		Order static parse(const std::string &input, std::vector<std::string>&err_msgs)
		{

			{
				
				Order order;
				std::vector<std::string> fields;
				std::stringstream s_stream(input); //create string stream from the string
				while (s_stream.good()) {
					std::string substr;
					getline(s_stream, substr, ','); //get first string delimited by comma
					fields.push_back(substr);
				}

				auto type_identifier = fields[0];

				if (type_identifier.compare(kNewOrder) == 0)
					order.type = 'N';
				else if (type_identifier.compare(kRemoveOrder) == 0)
					order.type ='R';
				else if (type_identifier.compare(kModifyOrder) == 0)
					order.type = 'M';
				else if (type_identifier.compare(kTradeOrder) == 0)
					order.type = 'X';
				else
					throw ParseException();
				// New Order
				if (order.type == 'N')
				{ // Add Order
					
					auto product_id = fields[1];
					auto p_id = std::stoi(product_id);
					if ( p_id< 0)
					{
						err_msgs.push_back("Product Id Negative" + std::stoul(product_id));

					}
					else
					{
						order.productid = std::stoul(product_id);
					}
					auto order_id = fields[2];
					auto o_id = std::stoi(order_id);
					if (o_id < 0)
					{
						err_msgs.push_back("Order Id Negative" + std::stoul(order_id));

					}
					else
					{
						order.orderid = std::stoul(order_id);
					}
					auto sideLiteral = fields[3];
					if (sideLiteral == kBuy)
						order.side = 'B';
					else if (sideLiteral == kSell)
						order.side ='S';
					else
						throw ParseException();

					//prize
					if (std::stof(fields[5]) < 0)
					{
						err_msgs.push_back("Negative Price :" + std::to_string(std::stof(fields[5])));
					}
					else
					{
						order.price = (std::stof(fields[5]));
					}

					//prize
					if (std::stof(fields[4]) < 0)
					{
						err_msgs.push_back("Negative quantity :" + std::to_string(std::stof(fields[4])));
					}
					else
					{
						order.quantity = (std::stof(fields[4]));
					}
				}

				// Remove Order Quantity
				else if (order.type == 'R')
				{					
					auto order_id = fields[1];
					auto o_idR = std::stoi(order_id);
					if (o_idR < 0)
					{
						err_msgs.push_back("Order Id Negative" + std::stoul(order_id));

					}
					else
					{
						order.orderid = std::stoul(order_id);
					}

					auto sideLiteral = fields[2];
					if (sideLiteral == kBuy)
						order.side = 'B';
					else if (sideLiteral == kSell)
						order.side = 'S';
					else
						throw ParseException();

					//prize
					if (std::stof(fields[4]) < 0)
					{
						err_msgs.push_back("Negative Price :" + std::to_string(std::stof(fields[5])));
					}
					else
					{
						order.price = (std::stof(fields[4]));
					}

					//quantity
					if (std::stof(fields[3]) < 0)
					{
						err_msgs.push_back("Negative quantity :" + std::to_string(std::stof(fields[4])));
					}
					else
					{
						order.quantity = (std::stof(fields[3]));
					}

				}

				//Modify Order
				else if (order.type == 'M')
				{
			
					auto order_id = fields[1];
					auto o_idM = std::stoi(order_id);
					if (o_idM < 0)
					{
						err_msgs.push_back("Order Id Negative" + std::stoul(order_id));

					}
					else
					{
						order.orderid = std::stoul(order_id);
					}
					auto sideLiteral = fields[2];
					if (sideLiteral == kBuy)
						order.side = 'B';
					else if (sideLiteral == kSell)
						order.side = 'S';
					else
						throw ParseException();

					//prize
					if (std::stof(fields[4]) < 0)
					{
						err_msgs.push_back("Negative Price :" + std::to_string(std::stof(fields[4])));
					}
					else
					{
						order.price = (std::stof(fields[4]));
					}

					//prize
					if (std::stof(fields[3]) < 0)
					{
						err_msgs.push_back("Negative quantity :" + std::to_string(std::stof(fields[3])));
					}
					else
					{
						order.price = (std::stof(fields[3]));
					}

				}

				// build the trade object from order object
				else if (order.type == 'X')
				{
		
					auto product_id = fields[1];
					if (std::stoul(product_id) < 0)
					{
						err_msgs.push_back("Negative Product ID :" + std::to_string(std::stoul(product_id)));
					}
					else
					{ 
						order.productid = std::stoul(product_id);
					}					
					//prize
					if (std::stof(fields[3]) < 0)
					{
						err_msgs.push_back("Negative Price :" + std::to_string(std::stof(fields[3])));
					}
					else
					{
						order.price = (std::stof(fields[3]));
					}

					//quantity
					if (std::stof(fields[2]) < 0)
					{
						err_msgs.push_back("Negative quantity :" + std::to_string(std::stof(fields[2])));
					}
					else
					{
						order.quantity = (std::stof(fields[2]));
					}

				}
				else
				{
					throw ParseException();
				}
				return order;

			}
		}
	};
}
