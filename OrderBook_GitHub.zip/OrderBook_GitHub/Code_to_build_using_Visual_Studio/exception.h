#pragma once

namespace marketData {

	// Main Exception
	class Exception 
	{
	};

	// Parsing exception
	class ParseException : public Exception 
	{
	};

	// Parsing exception
	class updateBooksException : public Exception
	{
	};


	// executeOrder exception
	class executeOrderException : public Exception 
	{
	};
}  

