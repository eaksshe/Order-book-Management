#include <string>
#include <unordered_map>
#include<unordered_set>
#include <map>
#include <set>
#include<unordered_set>
#include <functional>
#include "order.h"
#include "txtReader.h"
#include <sstream>
#include<vector>

typedef std::vector<marketData::Order> vecOforder;
typedef std::map<double, vecOforder> buyselldata;

namespace marketData
{

	class Trader
	{

	public:
		Trader() : myOrderBook(){}
		void processOrder(const std::string &input, std::vector<std::string>&err_msgs);
	private:
		Order order;
		Trade trade;
		std::map<marketData::Order::Id, buyselldata> product_id_to_sell;

		std::map<marketData::Order::Id, buyselldata> product_id_to_buy;

		std::unordered_map<marketData::Order::Id, Order> myOrderBook;

		void updateBooks(Order &order, std::vector<std::string>&err_msgs);
		void addToOrderBooks(Order &order, std::vector<std::string>&err_msgs);
		void removeFromOrderBooks(Order &order, std::vector<std::string>&err_msgs);
		void modifyOrderBooks(Order &order,std::vector<std::string>&err_msgs, bool bIsFromExecute=false);
		void executeTrade(Order &order, std::vector<std::string>&err_msgs);

		
	};
}
